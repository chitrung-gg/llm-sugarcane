mkdir -p ./data ./logs

sudo chown -R 10001:10001 ./data ./logs
