--
-- PostgreSQL database cluster dump
--

\restrict JP0wDAIFtX9ntWzrmxVrz3ekgdLbdSUPIt3o3QSBlzgi8fNoy1PYeVdUNOoROaQ

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE knowledge;
ALTER ROLE knowledge WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:6BCi3LRm9QblIwkj0eEGjQ==$8xkRj9/wTwmIqLjKv227/eTINYy47dyQpBSUdXZdTyY=:cgWeQpwtluFXmoGwVi/haWs3z3Nx3U10LRRntzIb3qQ=';
CREATE ROLE langgraph;
ALTER ROLE langgraph WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:lS1G+5useoIEGOIoDLZKuw==$5RxyGXe4Q+F+CTHFfqRFAVqSMZ7ObEX1PpOczrYOT+s=:DyWp5pR8X5Socx+CaBx07ES/fWIuVh7HaAC+VRngMRs=';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:EJjhV8Ae/Cx8kw6MepCkKQ==$5WjEXNw8KSa46Y7By6DPZ642evvW2FYWYGvxbKf5Ulk=:fFOKUe076haodoiiwff/v8CyAo9byfPzRzNd4fGPQ6g=';
CREATE ROLE userdata;
ALTER ROLE userdata WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:7viRrAwZd/UKY/NYa4l6rg==$tA3jvnAftC/+l8oL+eXogC2lTyzX3xpuNx8RKmMQx/k=:9o3lJRDd5hU+otBkb1zecZ1haOgvO1n2hI9kI/hrzbQ=';

--
-- User Configurations
--

--
-- User Config "knowledge"
--

ALTER ROLE knowledge SET search_path TO 'knowledge';

--
-- User Config "langgraph"
--

ALTER ROLE langgraph SET search_path TO 'langgraph';

--
-- User Config "userdata"
--

ALTER ROLE userdata SET search_path TO 'userdata';








\unrestrict JP0wDAIFtX9ntWzrmxVrz3ekgdLbdSUPIt3o3QSBlzgi8fNoy1PYeVdUNOoROaQ

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict lcrUiBCtFvZG1lGpjYp1XikuToPg2KvOWYNgoNu2zmpbcMFzan3H6AzPGnfnW97

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict lcrUiBCtFvZG1lGpjYp1XikuToPg2KvOWYNgoNu2zmpbcMFzan3H6AzPGnfnW97

--
-- Database "genome" dump
--

--
-- PostgreSQL database dump
--

\restrict jejXJgbXvdaW2dzhdo4kJn0iEjcOcgfMnvI62o688Y9Qwz2WsF9uiJcJQkzrcAe

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: genome; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE genome WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE genome OWNER TO postgres;

\unrestrict jejXJgbXvdaW2dzhdo4kJn0iEjcOcgfMnvI62o688Y9Qwz2WsF9uiJcJQkzrcAe
\connect genome
\restrict jejXJgbXvdaW2dzhdo4kJn0iEjcOcgfMnvI62o688Y9Qwz2WsF9uiJcJQkzrcAe

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: blast_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blast_tasks (
    id bigint NOT NULL,
    genome_id bigint NOT NULL,
    sequence text NOT NULL,
    evalue double precision DEFAULT 0.00001 NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    result_path text,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.blast_tasks OWNER TO postgres;

--
-- Name: blast_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blast_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blast_tasks_id_seq OWNER TO postgres;

--
-- Name: blast_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blast_tasks_id_seq OWNED BY public.blast_tasks.id;


--
-- Name: celery_taskmeta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.celery_taskmeta (
    id integer NOT NULL,
    task_id character varying(155),
    status character varying(50),
    result bytea,
    date_done timestamp without time zone,
    traceback text,
    name character varying(155),
    args bytea,
    kwargs bytea,
    worker character varying(155),
    retries integer,
    queue character varying(155)
);


ALTER TABLE public.celery_taskmeta OWNER TO postgres;

--
-- Name: celery_tasksetmeta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.celery_tasksetmeta (
    id integer NOT NULL,
    taskset_id character varying(155),
    result bytea,
    date_done timestamp without time zone
);


ALTER TABLE public.celery_tasksetmeta OWNER TO postgres;

--
-- Name: crispor_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crispor_tasks (
    id bigint NOT NULL,
    genome_id bigint NOT NULL,
    input_type character varying NOT NULL,
    gene_id character varying,
    raw_sequence text,
    status character varying DEFAULT 'PENDING'::character varying NOT NULL,
    guides_found integer,
    result_path text,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.crispor_tasks OWNER TO postgres;

--
-- Name: crispor_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.crispor_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.crispor_tasks_id_seq OWNER TO postgres;

--
-- Name: crispor_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.crispor_tasks_id_seq OWNED BY public.crispor_tasks.id;


--
-- Name: etl_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.etl_tasks (
    id bigint NOT NULL,
    genome_id bigint NOT NULL,
    file_type character varying(50) NOT NULL,
    s3_uri text NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    result_path text,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.etl_tasks OWNER TO postgres;

--
-- Name: etl_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.etl_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.etl_tasks_id_seq OWNER TO postgres;

--
-- Name: etl_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.etl_tasks_id_seq OWNED BY public.etl_tasks.id;


--
-- Name: genes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genes (
    id integer NOT NULL,
    gene_id character varying NOT NULL,
    name character varying,
    genome_id integer,
    chromosome character varying,
    start bigint,
    "end" bigint,
    strand character varying,
    description character varying,
    status character varying,
    created_at timestamp with time zone DEFAULT now(),
    global_id uuid DEFAULT public.uuid_generate_v4(),
    gene_metadata jsonb,
    knowledge_entity_id uuid
);


ALTER TABLE public.genes OWNER TO postgres;

--
-- Name: genes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.genes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.genes_id_seq OWNER TO postgres;

--
-- Name: genes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.genes_id_seq OWNED BY public.genes.id;


--
-- Name: genome_chromosome_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genome_chromosome_stats (
    id integer NOT NULL,
    genome_id integer NOT NULL,
    name character varying NOT NULL,
    length bigint NOT NULL,
    gene_count bigint DEFAULT 0 NOT NULL,
    gene_density double precision DEFAULT 0.0 NOT NULL,
    subgenome character varying,
    gc_content double precision DEFAULT 0.0 NOT NULL,
    gap_percentage double precision DEFAULT 0.0 NOT NULL,
    feature_breakdown jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.genome_chromosome_stats OWNER TO postgres;

--
-- Name: genome_chromosome_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.genome_chromosome_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.genome_chromosome_stats_id_seq OWNER TO postgres;

--
-- Name: genome_chromosome_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.genome_chromosome_stats_id_seq OWNED BY public.genome_chromosome_stats.id;


--
-- Name: genomes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genomes (
    id integer CONSTRAINT genome_files_id_not_null NOT NULL,
    name character varying,
    genome_path character varying,
    index_path character varying,
    blast_db_path character varying,
    status character varying,
    created_at timestamp with time zone DEFAULT now(),
    gff_path character varying,
    protein_path character varying,
    cds_path character varying,
    genotype character varying,
    gene_path character varying,
    global_id uuid DEFAULT public.uuid_generate_v4(),
    genome_metadata jsonb,
    dataset_id uuid,
    user_id uuid,
    is_public boolean
);


ALTER TABLE public.genomes OWNER TO postgres;

--
-- Name: genome_files_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.genome_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.genome_files_id_seq OWNER TO postgres;

--
-- Name: genome_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.genome_files_id_seq OWNED BY public.genomes.id;


--
-- Name: knowledge_entities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knowledge_entities (
    global_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    entity_type character varying NOT NULL,
    reference_sequence text,
    knowledge_entities_metadata jsonb,
    created_at timestamp with time zone DEFAULT now(),
    owner_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid,
    is_public boolean DEFAULT false
);


ALTER TABLE public.knowledge_entities OWNER TO postgres;

--
-- Name: knowledge_references; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knowledge_references (
    global_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title text NOT NULL,
    doi_or_url character varying,
    publication_year integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.knowledge_references OWNER TO postgres;

--
-- Name: primer_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.primer_tasks (
    id bigint NOT NULL,
    genome_id bigint NOT NULL,
    query text NOT NULL,
    primer_num_return integer DEFAULT 5 NOT NULL,
    product_size_range character varying DEFAULT '100-400'::character varying,
    opt_size integer DEFAULT 20,
    min_size integer DEFAULT 18,
    max_size integer DEFAULT 24,
    opt_tm double precision DEFAULT 60.0,
    min_tm double precision DEFAULT 52.0,
    max_tm double precision DEFAULT 68.0,
    opt_gc double precision DEFAULT 50.0,
    min_gc double precision DEFAULT 20.0,
    max_gc double precision DEFAULT 80.0,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    primers_found integer DEFAULT 0,
    result_path text,
    mode character varying(50),
    homologs_count integer,
    consensus_sequence text,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.primer_tasks OWNER TO postgres;

--
-- Name: primer_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.primer_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.primer_tasks_id_seq OWNER TO postgres;

--
-- Name: primer_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.primer_tasks_id_seq OWNED BY public.primer_tasks.id;


--
-- Name: synteny_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.synteny_tasks (
    id bigint NOT NULL,
    genome_a_id bigint NOT NULL,
    genome_b_id bigint NOT NULL,
    status character varying NOT NULL,
    quality_stats json,
    alignment_stats json,
    error_message character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    paf_file_path text,
    dotplot_s3_path character varying,
    archive_s3_path character varying
);


ALTER TABLE public.synteny_tasks OWNER TO postgres;

--
-- Name: synteny_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.synteny_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.synteny_tasks_id_seq OWNER TO postgres;

--
-- Name: synteny_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.synteny_tasks_id_seq OWNED BY public.synteny_tasks.id;


--
-- Name: task_id_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_id_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_id_sequence OWNER TO postgres;

--
-- Name: taskset_id_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.taskset_id_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.taskset_id_sequence OWNER TO postgres;

--
-- Name: blast_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blast_tasks ALTER COLUMN id SET DEFAULT nextval('public.blast_tasks_id_seq'::regclass);


--
-- Name: crispor_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crispor_tasks ALTER COLUMN id SET DEFAULT nextval('public.crispor_tasks_id_seq'::regclass);


--
-- Name: etl_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etl_tasks ALTER COLUMN id SET DEFAULT nextval('public.etl_tasks_id_seq'::regclass);


--
-- Name: genes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genes ALTER COLUMN id SET DEFAULT nextval('public.genes_id_seq'::regclass);


--
-- Name: genome_chromosome_stats id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genome_chromosome_stats ALTER COLUMN id SET DEFAULT nextval('public.genome_chromosome_stats_id_seq'::regclass);


--
-- Name: genomes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genomes ALTER COLUMN id SET DEFAULT nextval('public.genome_files_id_seq'::regclass);


--
-- Name: primer_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.primer_tasks ALTER COLUMN id SET DEFAULT nextval('public.primer_tasks_id_seq'::regclass);


--
-- Name: synteny_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.synteny_tasks ALTER COLUMN id SET DEFAULT nextval('public.synteny_tasks_id_seq'::regclass);


--
-- Name: blast_tasks blast_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blast_tasks
    ADD CONSTRAINT blast_tasks_pkey PRIMARY KEY (id);


--
-- Name: celery_taskmeta celery_taskmeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.celery_taskmeta
    ADD CONSTRAINT celery_taskmeta_pkey PRIMARY KEY (id);


--
-- Name: celery_taskmeta celery_taskmeta_task_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.celery_taskmeta
    ADD CONSTRAINT celery_taskmeta_task_id_key UNIQUE (task_id);


--
-- Name: celery_tasksetmeta celery_tasksetmeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.celery_tasksetmeta
    ADD CONSTRAINT celery_tasksetmeta_pkey PRIMARY KEY (id);


--
-- Name: celery_tasksetmeta celery_tasksetmeta_taskset_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.celery_tasksetmeta
    ADD CONSTRAINT celery_tasksetmeta_taskset_id_key UNIQUE (taskset_id);


--
-- Name: crispor_tasks crispor_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crispor_tasks
    ADD CONSTRAINT crispor_tasks_pkey PRIMARY KEY (id);


--
-- Name: etl_tasks etl_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etl_tasks
    ADD CONSTRAINT etl_tasks_pkey PRIMARY KEY (id);


--
-- Name: genes genes_global_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genes
    ADD CONSTRAINT genes_global_id_key UNIQUE (global_id);


--
-- Name: genes genes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genes
    ADD CONSTRAINT genes_pkey PRIMARY KEY (id);


--
-- Name: genome_chromosome_stats genome_chromosome_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genome_chromosome_stats
    ADD CONSTRAINT genome_chromosome_stats_pkey PRIMARY KEY (id);


--
-- Name: genomes genome_files_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genomes
    ADD CONSTRAINT genome_files_pkey PRIMARY KEY (id);


--
-- Name: genomes genomes_global_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genomes
    ADD CONSTRAINT genomes_global_id_key UNIQUE (global_id);


--
-- Name: knowledge_entities knowledge_entities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_entities
    ADD CONSTRAINT knowledge_entities_pkey PRIMARY KEY (global_id);


--
-- Name: knowledge_references knowledge_references_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_references
    ADD CONSTRAINT knowledge_references_pkey PRIMARY KEY (global_id);


--
-- Name: primer_tasks primer_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.primer_tasks
    ADD CONSTRAINT primer_tasks_pkey PRIMARY KEY (id);


--
-- Name: synteny_tasks synteny_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.synteny_tasks
    ADD CONSTRAINT synteny_tasks_pkey PRIMARY KEY (id);


--
-- Name: knowledge_entities uq_knowledge_entity_name_type_owner; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_entities
    ADD CONSTRAINT uq_knowledge_entity_name_type_owner UNIQUE (name, entity_type, owner_id);


--
-- Name: knowledge_references uq_knowledge_reference_title; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_references
    ADD CONSTRAINT uq_knowledge_reference_title UNIQUE (title);


--
-- Name: idx_blast_tasks_genome_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_blast_tasks_genome_id ON public.blast_tasks USING btree (genome_id);


--
-- Name: idx_blast_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_blast_tasks_status ON public.blast_tasks USING btree (status);


--
-- Name: idx_crispor_tasks_gene_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crispor_tasks_gene_id ON public.crispor_tasks USING btree (gene_id);


--
-- Name: idx_crispor_tasks_genome_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crispor_tasks_genome_id ON public.crispor_tasks USING btree (genome_id);


--
-- Name: idx_crispor_tasks_input_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crispor_tasks_input_type ON public.crispor_tasks USING btree (input_type);


--
-- Name: idx_crispor_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crispor_tasks_status ON public.crispor_tasks USING btree (status);


--
-- Name: idx_etl_tasks_file_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_etl_tasks_file_type ON public.etl_tasks USING btree (file_type);


--
-- Name: idx_etl_tasks_genome_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_etl_tasks_genome_id ON public.etl_tasks USING btree (genome_id);


--
-- Name: idx_etl_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_etl_tasks_status ON public.etl_tasks USING btree (status);


--
-- Name: idx_gene_metadata; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_gene_metadata ON public.genes USING gin (gene_metadata);


--
-- Name: idx_genome_loc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_genome_loc ON public.genes USING btree (genome_id, chromosome, start, "end");


--
-- Name: idx_genome_metadata; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_genome_metadata ON public.genomes USING gin (genome_metadata);


--
-- Name: idx_primer_tasks_genome_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_primer_tasks_genome_id ON public.primer_tasks USING btree (genome_id);


--
-- Name: idx_primer_tasks_mode; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_primer_tasks_mode ON public.primer_tasks USING btree (mode);


--
-- Name: idx_primer_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_primer_tasks_status ON public.primer_tasks USING btree (status);


--
-- Name: ix_genes_end; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genes_end ON public.genes USING btree ("end");


--
-- Name: ix_genes_gene_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genes_gene_id ON public.genes USING btree (gene_id);


--
-- Name: ix_genes_genome_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genes_genome_id ON public.genes USING btree (genome_id);


--
-- Name: ix_genes_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genes_id ON public.genes USING btree (id);


--
-- Name: ix_genes_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genes_name ON public.genes USING btree (name);


--
-- Name: ix_genes_start; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genes_start ON public.genes USING btree (start);


--
-- Name: ix_genome_chromosome_stats_genome_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genome_chromosome_stats_genome_id ON public.genome_chromosome_stats USING btree (genome_id);


--
-- Name: ix_genome_chromosome_stats_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genome_chromosome_stats_id ON public.genome_chromosome_stats USING btree (id);


--
-- Name: ix_genome_chromosome_stats_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genome_chromosome_stats_name ON public.genome_chromosome_stats USING btree (name);


--
-- Name: ix_genome_chromosome_stats_subgenome; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genome_chromosome_stats_subgenome ON public.genome_chromosome_stats USING btree (subgenome);


--
-- Name: ix_genome_files_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genome_files_id ON public.genomes USING btree (id);


--
-- Name: ix_genome_files_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_genome_files_name ON public.genomes USING btree (name);


--
-- Name: ix_synteny_tasks_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_synteny_tasks_id ON public.synteny_tasks USING btree (id);


--
-- Name: genome_chromosome_stats fk_genome_chromosome_stats_genome_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genome_chromosome_stats
    ADD CONSTRAINT fk_genome_chromosome_stats_genome_id FOREIGN KEY (genome_id) REFERENCES public.genomes(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict jejXJgbXvdaW2dzhdo4kJn0iEjcOcgfMnvI62o688Y9Qwz2WsF9uiJcJQkzrcAe

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict c9HBVwzTbwIFfLLZ12OxzfM3H3OPVCwBRV2ykTfDcWwZoYNneERBehNKgQ0tQzh

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict c9HBVwzTbwIFfLLZ12OxzfM3H3OPVCwBRV2ykTfDcWwZoYNneERBehNKgQ0tQzh

--
-- Database "sugarcane" dump
--

--
-- PostgreSQL database dump
--

\restrict YkejdrWBiw8rKZPRBpqLcaekxmBZFJUSP99c5Htt7GFdU00h9a8WQxaYIh1qeLD

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: sugarcane; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sugarcane WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE sugarcane OWNER TO postgres;

\unrestrict YkejdrWBiw8rKZPRBpqLcaekxmBZFJUSP99c5Htt7GFdU00h9a8WQxaYIh1qeLD
\connect sugarcane
\restrict YkejdrWBiw8rKZPRBpqLcaekxmBZFJUSP99c5Htt7GFdU00h9a8WQxaYIh1qeLD

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: knowledge; Type: SCHEMA; Schema: -; Owner: knowledge
--

CREATE SCHEMA knowledge;


ALTER SCHEMA knowledge OWNER TO knowledge;

--
-- Name: langgraph; Type: SCHEMA; Schema: -; Owner: langgraph
--

CREATE SCHEMA langgraph;


ALTER SCHEMA langgraph OWNER TO langgraph;

--
-- Name: userdata; Type: SCHEMA; Schema: -; Owner: userdata
--

CREATE SCHEMA userdata;


ALTER SCHEMA userdata OWNER TO userdata;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA userdata;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: celery_taskmeta; Type: TABLE; Schema: knowledge; Owner: knowledge
--

CREATE TABLE knowledge.celery_taskmeta (
    id integer NOT NULL,
    task_id character varying(155),
    status character varying(50),
    result bytea,
    date_done timestamp without time zone,
    traceback text,
    name character varying(155),
    args bytea,
    kwargs bytea,
    worker character varying(155),
    retries integer,
    queue character varying(155)
);


ALTER TABLE knowledge.celery_taskmeta OWNER TO knowledge;

--
-- Name: celery_tasksetmeta; Type: TABLE; Schema: knowledge; Owner: knowledge
--

CREATE TABLE knowledge.celery_tasksetmeta (
    id integer NOT NULL,
    taskset_id character varying(155),
    result bytea,
    date_done timestamp without time zone
);


ALTER TABLE knowledge.celery_tasksetmeta OWNER TO knowledge;

--
-- Name: task_id_sequence; Type: SEQUENCE; Schema: knowledge; Owner: knowledge
--

CREATE SEQUENCE knowledge.task_id_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE knowledge.task_id_sequence OWNER TO knowledge;

--
-- Name: taskset_id_sequence; Type: SEQUENCE; Schema: knowledge; Owner: knowledge
--

CREATE SEQUENCE knowledge.taskset_id_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE knowledge.taskset_id_sequence OWNER TO knowledge;

--
-- Name: chat_messages; Type: TABLE; Schema: langgraph; Owner: postgres
--

CREATE TABLE langgraph.chat_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    execution_id uuid,
    role text NOT NULL,
    type text DEFAULT 'answer'::text NOT NULL,
    content text NOT NULL,
    chat_metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE langgraph.chat_messages OWNER TO postgres;

--
-- Name: chat_threads; Type: TABLE; Schema: langgraph; Owner: postgres
--

CREATE TABLE langgraph.chat_threads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    thread_id uuid NOT NULL,
    project_id uuid,
    title text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE langgraph.chat_threads OWNER TO postgres;

--
-- Name: checkpoint_blobs; Type: TABLE; Schema: langgraph; Owner: langgraph
--

CREATE TABLE langgraph.checkpoint_blobs (
    thread_id text NOT NULL,
    checkpoint_ns text DEFAULT ''::text NOT NULL,
    channel text NOT NULL,
    version text NOT NULL,
    type text NOT NULL,
    blob bytea
);


ALTER TABLE langgraph.checkpoint_blobs OWNER TO langgraph;

--
-- Name: checkpoint_migrations; Type: TABLE; Schema: langgraph; Owner: langgraph
--

CREATE TABLE langgraph.checkpoint_migrations (
    v integer NOT NULL
);


ALTER TABLE langgraph.checkpoint_migrations OWNER TO langgraph;

--
-- Name: checkpoint_writes; Type: TABLE; Schema: langgraph; Owner: langgraph
--

CREATE TABLE langgraph.checkpoint_writes (
    thread_id text NOT NULL,
    checkpoint_ns text DEFAULT ''::text NOT NULL,
    checkpoint_id text NOT NULL,
    task_id text NOT NULL,
    idx integer NOT NULL,
    channel text NOT NULL,
    type text,
    blob bytea NOT NULL,
    task_path text DEFAULT ''::text NOT NULL
);


ALTER TABLE langgraph.checkpoint_writes OWNER TO langgraph;

--
-- Name: checkpoints; Type: TABLE; Schema: langgraph; Owner: langgraph
--

CREATE TABLE langgraph.checkpoints (
    thread_id text NOT NULL,
    checkpoint_ns text DEFAULT ''::text NOT NULL,
    checkpoint_id text NOT NULL,
    parent_checkpoint_id text,
    type text,
    checkpoint jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE langgraph.checkpoints OWNER TO langgraph;

--
-- Name: store; Type: TABLE; Schema: langgraph; Owner: langgraph
--

CREATE TABLE langgraph.store (
    prefix text NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    ttl_minutes integer
);


ALTER TABLE langgraph.store OWNER TO langgraph;

--
-- Name: store_migrations; Type: TABLE; Schema: langgraph; Owner: langgraph
--

CREATE TABLE langgraph.store_migrations (
    v integer NOT NULL
);


ALTER TABLE langgraph.store_migrations OWNER TO langgraph;

--
-- Name: knowledge_file_links; Type: TABLE; Schema: userdata; Owner: postgres
--

CREATE TABLE userdata.knowledge_file_links (
    file_id uuid NOT NULL,
    knowledge_entity_id uuid NOT NULL,
    relevance_score double precision
);


ALTER TABLE userdata.knowledge_file_links OWNER TO postgres;

--
-- Name: project_dataset_attachments; Type: TABLE; Schema: userdata; Owner: postgres
--

CREATE TABLE userdata.project_dataset_attachments (
    project_id uuid NOT NULL,
    dataset_id uuid NOT NULL,
    attached_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE userdata.project_dataset_attachments OWNER TO postgres;

--
-- Name: user_dataset_files; Type: TABLE; Schema: userdata; Owner: postgres
--

CREATE TABLE userdata.user_dataset_files (
    id uuid DEFAULT userdata.uuid_generate_v4() NOT NULL,
    dataset_id uuid NOT NULL,
    file_name character varying NOT NULL,
    file_type character varying NOT NULL,
    rustfs_uri character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    file_metadata jsonb,
    genome_global_id uuid
);


ALTER TABLE userdata.user_dataset_files OWNER TO postgres;

--
-- Name: user_datasets; Type: TABLE; Schema: userdata; Owner: postgres
--

CREATE TABLE userdata.user_datasets (
    id uuid DEFAULT userdata.uuid_generate_v4() NOT NULL,
    project_id uuid NOT NULL,
    file_id uuid,
    file_name character varying,
    file_type character varying,
    rustfs_uri character varying,
    dataset_metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    name character varying,
    description text,
    is_public boolean DEFAULT false
);


ALTER TABLE userdata.user_datasets OWNER TO postgres;

--
-- Name: user_projects; Type: TABLE; Schema: userdata; Owner: postgres
--

CREATE TABLE userdata.user_projects (
    id uuid DEFAULT userdata.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    dataset_metadata jsonb,
    owner_id uuid
);


ALTER TABLE userdata.user_projects OWNER TO postgres;

--
-- Name: celery_taskmeta celery_taskmeta_pkey; Type: CONSTRAINT; Schema: knowledge; Owner: knowledge
--

ALTER TABLE ONLY knowledge.celery_taskmeta
    ADD CONSTRAINT celery_taskmeta_pkey PRIMARY KEY (id);


--
-- Name: celery_taskmeta celery_taskmeta_task_id_key; Type: CONSTRAINT; Schema: knowledge; Owner: knowledge
--

ALTER TABLE ONLY knowledge.celery_taskmeta
    ADD CONSTRAINT celery_taskmeta_task_id_key UNIQUE (task_id);


--
-- Name: celery_tasksetmeta celery_tasksetmeta_pkey; Type: CONSTRAINT; Schema: knowledge; Owner: knowledge
--

ALTER TABLE ONLY knowledge.celery_tasksetmeta
    ADD CONSTRAINT celery_tasksetmeta_pkey PRIMARY KEY (id);


--
-- Name: celery_tasksetmeta celery_tasksetmeta_taskset_id_key; Type: CONSTRAINT; Schema: knowledge; Owner: knowledge
--

ALTER TABLE ONLY knowledge.celery_tasksetmeta
    ADD CONSTRAINT celery_tasksetmeta_taskset_id_key UNIQUE (taskset_id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: langgraph; Owner: postgres
--

ALTER TABLE ONLY langgraph.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: chat_threads chat_threads_pkey; Type: CONSTRAINT; Schema: langgraph; Owner: postgres
--

ALTER TABLE ONLY langgraph.chat_threads
    ADD CONSTRAINT chat_threads_pkey PRIMARY KEY (id);


--
-- Name: chat_threads chat_threads_thread_id_key; Type: CONSTRAINT; Schema: langgraph; Owner: postgres
--

ALTER TABLE ONLY langgraph.chat_threads
    ADD CONSTRAINT chat_threads_thread_id_key UNIQUE (thread_id);


--
-- Name: checkpoint_blobs checkpoint_blobs_pkey; Type: CONSTRAINT; Schema: langgraph; Owner: langgraph
--

ALTER TABLE ONLY langgraph.checkpoint_blobs
    ADD CONSTRAINT checkpoint_blobs_pkey PRIMARY KEY (thread_id, checkpoint_ns, channel, version);


--
-- Name: checkpoint_migrations checkpoint_migrations_pkey; Type: CONSTRAINT; Schema: langgraph; Owner: langgraph
--

ALTER TABLE ONLY langgraph.checkpoint_migrations
    ADD CONSTRAINT checkpoint_migrations_pkey PRIMARY KEY (v);


--
-- Name: checkpoint_writes checkpoint_writes_pkey; Type: CONSTRAINT; Schema: langgraph; Owner: langgraph
--

ALTER TABLE ONLY langgraph.checkpoint_writes
    ADD CONSTRAINT checkpoint_writes_pkey PRIMARY KEY (thread_id, checkpoint_ns, checkpoint_id, task_id, idx);


--
-- Name: checkpoints checkpoints_pkey; Type: CONSTRAINT; Schema: langgraph; Owner: langgraph
--

ALTER TABLE ONLY langgraph.checkpoints
    ADD CONSTRAINT checkpoints_pkey PRIMARY KEY (thread_id, checkpoint_ns, checkpoint_id);


--
-- Name: store_migrations store_migrations_pkey; Type: CONSTRAINT; Schema: langgraph; Owner: langgraph
--

ALTER TABLE ONLY langgraph.store_migrations
    ADD CONSTRAINT store_migrations_pkey PRIMARY KEY (v);


--
-- Name: store store_pkey; Type: CONSTRAINT; Schema: langgraph; Owner: langgraph
--

ALTER TABLE ONLY langgraph.store
    ADD CONSTRAINT store_pkey PRIMARY KEY (prefix, key);


--
-- Name: knowledge_file_links pk_knowledge_file_links; Type: CONSTRAINT; Schema: userdata; Owner: postgres
--

ALTER TABLE ONLY userdata.knowledge_file_links
    ADD CONSTRAINT pk_knowledge_file_links PRIMARY KEY (file_id, knowledge_entity_id);


--
-- Name: project_dataset_attachments project_dataset_attachments_pkey; Type: CONSTRAINT; Schema: userdata; Owner: postgres
--

ALTER TABLE ONLY userdata.project_dataset_attachments
    ADD CONSTRAINT project_dataset_attachments_pkey PRIMARY KEY (project_id, dataset_id);


--
-- Name: user_dataset_files user_dataset_files_pkey; Type: CONSTRAINT; Schema: userdata; Owner: postgres
--

ALTER TABLE ONLY userdata.user_dataset_files
    ADD CONSTRAINT user_dataset_files_pkey PRIMARY KEY (id);


--
-- Name: user_datasets user_datasets_pkey; Type: CONSTRAINT; Schema: userdata; Owner: postgres
--

ALTER TABLE ONLY userdata.user_datasets
    ADD CONSTRAINT user_datasets_pkey PRIMARY KEY (id);


--
-- Name: user_projects user_projects_pkey; Type: CONSTRAINT; Schema: userdata; Owner: postgres
--

ALTER TABLE ONLY userdata.user_projects
    ADD CONSTRAINT user_projects_pkey PRIMARY KEY (id);


--
-- Name: ix_celery_taskmeta_date_done; Type: INDEX; Schema: knowledge; Owner: knowledge
--

CREATE INDEX ix_celery_taskmeta_date_done ON knowledge.celery_taskmeta USING btree (date_done);


--
-- Name: ix_celery_tasksetmeta_date_done; Type: INDEX; Schema: knowledge; Owner: knowledge
--

CREATE INDEX ix_celery_tasksetmeta_date_done ON knowledge.celery_tasksetmeta USING btree (date_done);


--
-- Name: checkpoint_blobs_thread_id_idx; Type: INDEX; Schema: langgraph; Owner: langgraph
--

CREATE INDEX checkpoint_blobs_thread_id_idx ON langgraph.checkpoint_blobs USING btree (thread_id);


--
-- Name: checkpoint_writes_thread_id_idx; Type: INDEX; Schema: langgraph; Owner: langgraph
--

CREATE INDEX checkpoint_writes_thread_id_idx ON langgraph.checkpoint_writes USING btree (thread_id);


--
-- Name: checkpoints_thread_id_idx; Type: INDEX; Schema: langgraph; Owner: langgraph
--

CREATE INDEX checkpoints_thread_id_idx ON langgraph.checkpoints USING btree (thread_id);


--
-- Name: idx_messages_thread_id; Type: INDEX; Schema: langgraph; Owner: postgres
--

CREATE INDEX idx_messages_thread_id ON langgraph.chat_messages USING btree (thread_id);


--
-- Name: idx_store_expires_at; Type: INDEX; Schema: langgraph; Owner: langgraph
--

CREATE INDEX idx_store_expires_at ON langgraph.store USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_threads_user_id; Type: INDEX; Schema: langgraph; Owner: postgres
--

CREATE INDEX idx_threads_user_id ON langgraph.chat_threads USING btree (user_id);


--
-- Name: store_prefix_idx; Type: INDEX; Schema: langgraph; Owner: langgraph
--

CREATE INDEX store_prefix_idx ON langgraph.store USING btree (prefix text_pattern_ops);


--
-- Name: ix_user_dataset_files_dataset_id; Type: INDEX; Schema: userdata; Owner: postgres
--

CREATE INDEX ix_user_dataset_files_dataset_id ON userdata.user_dataset_files USING btree (dataset_id);


--
-- Name: ix_user_datasets_file_id; Type: INDEX; Schema: userdata; Owner: postgres
--

CREATE INDEX ix_user_datasets_file_id ON userdata.user_datasets USING btree (file_id);


--
-- Name: ix_user_datasets_is_public; Type: INDEX; Schema: userdata; Owner: postgres
--

CREATE INDEX ix_user_datasets_is_public ON userdata.user_datasets USING btree (is_public);


--
-- Name: ix_user_datasets_project_id; Type: INDEX; Schema: userdata; Owner: postgres
--

CREATE INDEX ix_user_datasets_project_id ON userdata.user_datasets USING btree (project_id);


--
-- Name: ix_user_projects_name; Type: INDEX; Schema: userdata; Owner: postgres
--

CREATE INDEX ix_user_projects_name ON userdata.user_projects USING btree (name);


--
-- Name: chat_messages chat_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: langgraph; Owner: postgres
--

ALTER TABLE ONLY langgraph.chat_messages
    ADD CONSTRAINT chat_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES langgraph.chat_threads(thread_id) ON DELETE CASCADE;


--
-- Name: chat_threads chat_threads_project_id_fkey; Type: FK CONSTRAINT; Schema: langgraph; Owner: postgres
--

ALTER TABLE ONLY langgraph.chat_threads
    ADD CONSTRAINT chat_threads_project_id_fkey FOREIGN KEY (project_id) REFERENCES userdata.user_projects(id);


--
-- Name: user_dataset_files fk_dataset_files; Type: FK CONSTRAINT; Schema: userdata; Owner: postgres
--

ALTER TABLE ONLY userdata.user_dataset_files
    ADD CONSTRAINT fk_dataset_files FOREIGN KEY (dataset_id) REFERENCES userdata.user_datasets(id) ON DELETE CASCADE;


--
-- Name: user_datasets fk_user_projects; Type: FK CONSTRAINT; Schema: userdata; Owner: postgres
--

ALTER TABLE ONLY userdata.user_datasets
    ADD CONSTRAINT fk_user_projects FOREIGN KEY (project_id) REFERENCES userdata.user_projects(id) ON DELETE CASCADE;


--
-- Name: project_dataset_attachments project_dataset_attachments_dataset_id_fkey; Type: FK CONSTRAINT; Schema: userdata; Owner: postgres
--

ALTER TABLE ONLY userdata.project_dataset_attachments
    ADD CONSTRAINT project_dataset_attachments_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES userdata.user_datasets(id) ON DELETE CASCADE;


--
-- Name: project_dataset_attachments project_dataset_attachments_project_id_fkey; Type: FK CONSTRAINT; Schema: userdata; Owner: postgres
--

ALTER TABLE ONLY userdata.project_dataset_attachments
    ADD CONSTRAINT project_dataset_attachments_project_id_fkey FOREIGN KEY (project_id) REFERENCES userdata.user_projects(id) ON DELETE CASCADE;


--
-- Name: TABLE chat_messages; Type: ACL; Schema: langgraph; Owner: postgres
--

GRANT ALL ON TABLE langgraph.chat_messages TO langgraph;


--
-- Name: TABLE chat_threads; Type: ACL; Schema: langgraph; Owner: postgres
--

GRANT ALL ON TABLE langgraph.chat_threads TO langgraph;


--
-- Name: TABLE knowledge_file_links; Type: ACL; Schema: userdata; Owner: postgres
--

GRANT ALL ON TABLE userdata.knowledge_file_links TO userdata;


--
-- Name: TABLE project_dataset_attachments; Type: ACL; Schema: userdata; Owner: postgres
--

GRANT ALL ON TABLE userdata.project_dataset_attachments TO userdata;


--
-- Name: TABLE user_dataset_files; Type: ACL; Schema: userdata; Owner: postgres
--

GRANT ALL ON TABLE userdata.user_dataset_files TO userdata;


--
-- Name: TABLE user_datasets; Type: ACL; Schema: userdata; Owner: postgres
--

GRANT ALL ON TABLE userdata.user_datasets TO userdata;


--
-- Name: TABLE user_projects; Type: ACL; Schema: userdata; Owner: postgres
--

GRANT ALL ON TABLE userdata.user_projects TO userdata;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: langgraph; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA langgraph GRANT ALL ON SEQUENCES TO langgraph;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: langgraph; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA langgraph GRANT ALL ON TABLES TO langgraph;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: userdata; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA userdata GRANT ALL ON SEQUENCES TO userdata;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: userdata; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA userdata GRANT ALL ON TABLES TO userdata;


--
-- PostgreSQL database dump complete
--

\unrestrict YkejdrWBiw8rKZPRBpqLcaekxmBZFJUSP99c5Htt7GFdU00h9a8WQxaYIh1qeLD

--
-- PostgreSQL database cluster dump complete
--

